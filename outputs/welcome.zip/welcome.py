def hello(event, context):
    print ("Welocome to terraform")
